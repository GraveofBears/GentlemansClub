<h1 align="center" style="font-size: 50px; color: #d3d8de; text-shadow: 2px 2px 4px #000000;">💃 EMBERVILLE AFTER DARK 💃</h1>

<p align="center">
<b style="color: #9aa3ae; font-size: 1.3em;">An OdinPlus mod for Emberville. Use Gale Mod Manager to get the latest updates from OdinPlus!</b>
</p>

<div style="background-color: #15171a; padding: 25px; border: 2px solid #454a52; color: #c2c7ce; border-radius: 8px;">

<h2 style="color: #aab2bd; border-bottom: 2px solid #454a52; padding-bottom: 5px;">ABOUT:</h2>
<p style="color: #a4abb5;"><b>Emberville After Dark</b> shows you what the town gets up to after sundown: the <b>Gentleman's Club</b>, a cabaret club. Walk in through the front door to a neon-lit room with dancers on the poles, girls who chat and gossip, a barkeep with very high prices and a VIP room guarded by a bouncer. <i>Look, but don't touch.</i></p>
<p style="color: #a4abb5;"><b>Note:</b> the humour is cheeky and adult (suggestive, never explicit). There's drinking, and a made-up in-game drug called Glimmerdust.</p>

<h2 style="color: #aab2bd; border-bottom: 2px solid #454a52; padding-bottom: 5px;">FEATURES:</h2>

<ul style="color: #c2c7ce; list-style-type: square;">
    <li><b style="color: #8a94a1;">Its own interior:</b> enter through the club's door to a separate room with a stage, a bar, booths, spotlights that sweep and neon that flickers.</li>
    <li><b style="color: #8a94a1;">Stage dancers:</b> Ruby, Violet and Mocha dance on the poles. Each girl always has the same look, chosen to suit her personality.</li>
    <li><b style="color: #8a94a1;">Club-goers:</b> girls who walk the aisles without bumping into each other, all with lots to say about life on the pole. Talk to them, tip them, or take one adventuring. She'll follow you out into the world and complain that you never take her to dinner.</li>
    <li><b style="color: #8a94a1;">The barkeep:</b> house rules, terrible jokes and a drinks menu. The <b>Neon Ember</b> cocktail heals a little and gets you drunk. Drink too many and you'll pass out and wake up lighter in the purse.</li>
    <li><b style="color: #8a94a1;">Make it rain:</b> throw coins at a dancer and watch them shower down.</li>
    <li><b style="color: #8a94a1;">The VIP room:</b> the bouncer stands in the doorway until you pay him, or bribe him. Then he steps aside, and Ruby gives private dances inside.</li>
    <li><b style="color: #8a94a1;">Trixie:</b> she talks very fast and sells <b>Glimmerdust</b>. It makes you faster for a while, then you crash and you're slower.</li>
    <li><b style="color: #8a94a1;">Music playlist:</b> plays only inside the club and follows the game's Main and Music volume sliders. Drop your own MP3s into the mod's <code>audio</code> folder to add them to the playlist.</li>
    <li><b style="color: #8a94a1;">Edit what everyone says:</b> all the lines are in <code>text/club_lines.txt</code>. Add a new <code>[girl:Name]</code> section and she'll start turning up at the club.</li>
</ul>

<h2 style="color: #aab2bd; border-bottom: 2px solid #454a52; padding-bottom: 5px;">HOW TO USE:</h2>
<ul style="color: #c2c7ce; list-style-type: square;">
    <li>The club is already built in the starting area the first time you play.</li>
    <li>With <b>Debug / DebugMode</b> turned on in the config: <b>Ctrl+T</b> moves the club in front of you (in whatever area you're in), <b>Ctrl+Shift+T</b> removes it from the current area, and <b>Ctrl+Shift+G</b> gives you 500 coins. Moves are remembered between sessions, and a removal stays in effect while debug mode is on. Turn debug mode off and the club is back. Step outside the club first.</li>
    <li>Walk up to anyone in the club and use the game's interact button to talk.</li>
</ul>

<h2 style="color: #aab2bd; border-bottom: 2px solid #454a52; padding-bottom: 5px;">CONFIGURATION:</h2>
<p style="color: #a4abb5;">Run the game once, then edit <code>BepInEx/config/OdinPlus.EmbervilleAfterDark.cfg</code>:</p>
<ul style="color: #c2c7ce; list-style-type: square;">
    <li><b>Debug / DebugMode</b> (false): turns on the keys below. While it's off, the club stays put and the keys do nothing.</li>
    <li><b>Debug / SpawnKey</b> (Ctrl+T), <b>RemoveKey</b> (Ctrl+Shift+T), <b>GoldKey</b> (Ctrl+Shift+G) and <b>GoldAmount</b> (500): a Unity Input System key name, optionally with <code>Ctrl+</code>, <code>Shift+</code> or <code>Alt+</code> in front, or <code>None</code>.</li>
    <li><b>Bar / Stock</b>: what the barkeep sells, as the game's item keys with a min-max amount.</li>
    <li><b>Club / TipSmall</b> (10), <b>TipBig</b> (50), <b>MakeItRain</b> (50), <b>MakeItPour</b> (200), <b>VipPass</b> (100), <b>PrivateDance</b> (100): prices in coins.</li>
    <li><b>Club / Bouncer</b> (true): set to false to leave the VIP room open. <b>ClubGoers</b> (3): how many girls walk the club, 0 to 10.</li>
    <li><b>Drinks / SecondsPerDrink</b> (75): how long each Neon Ember keeps you drunk.</li>
    <li><b>Glimmerdust</b>: the price and how long the high and the crash last, plus how much faster or slower you get (in percent).</li>
    <li><b>Music / Volume</b> (0.6), <b>File</b> (<code>*</code> plays every MP3 in the <code>audio</code> folder; a file name loops just that song; leave it empty for no music), <b>Shuffle</b> (true).</li>
</ul>

<h2 style="color: #aab2bd; border-bottom: 2px solid #454a52; padding-bottom: 5px;">INSTALLATION:</h2>
<ol style="color: #a4abb5;">
    <li>Install <b>BepInEx 5</b> (Mono) for Emberville.</li>
    <li>Place the <b>EmbervilleAfterDark</b> folder directly into <code>BepInEx/plugins/</code>, keeping its <code>audio</code> and <code>text</code> folders and the <code>gentlemansclub</code> file next to the DLL. If you had the older <b>GentlemansClub</b> version, delete its folder: your settings and the club's spot carry over by themselves.</li>
    <li>Start the game. This mod works on your own game only, so it doesn't need to be installed on anyone else's.</li>
</ol>

<h2 style="color: #aab2bd; border-bottom: 2px solid #454a52; padding-bottom: 5px;">DISTRIBUTION:</h2>
<p style="color: #a4abb5;">Feel free to include this in your modpacks! Just don't recompile and claim the code as your own. Special thanks to the <b>OdinPlus Team</b> for their tireless work.</p>

<hr style="border: 1px solid #454a52;">

<h2 style="color: #aab2bd; text-align: center;">SHOW YOUR SUPPORT:</h2>
<p align="center" style="color: #c2c7ce;"><i>Click to BuyMeACoffee:</i></p>
<p align="center">
<a href="https://www.buymeacoffee.com/Gravebear"><img src="https://noobtrap.eu/images/crystallights/GBSupporter.png"></a>
</p>

<h2 style="color: #aab2bd; text-align: center;">QUESTIONS?</h2>
<p align="center">
<a href="https://discord.gg/mbkPcvu9ax"><img src="https://i.imgur.com/Ji3u63C.png"></a>
</p>

</div>
