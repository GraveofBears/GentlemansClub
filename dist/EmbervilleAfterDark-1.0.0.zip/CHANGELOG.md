# Changelog

### 1.0.0 (Brought to you by GraveBear)
- First release of Emberville After Dark: the Gentleman's Club, with its own interior, stage dancers, club-goers, barkeep, VIP room and bouncer, drinks, Glimmerdust and a music playlist.
- The club is already standing in the starting area on a new install. Debug mode (off by default) adds keys to move or remove it and a coin cheat for testing.
